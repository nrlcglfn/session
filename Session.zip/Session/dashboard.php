<?php

include "connection.php";

session_start();

$timeout_duration = 10;

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset(); 
    session_destroy(); 
    header("Location: index.php");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();

if (!isset($_SESSION['user_name']) || $_SESSION['name'] !== 'Mayvelyn') {
    header("Location: index.php");
    exit();
}

if (isset($_SESSION['name'])) {
    $name = $_SESSION['name'];
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body class='d-flex align-items-center justify-content-center' style='height: 100vh;'>
    
    <div class="row justify-content-center d-flex">
        <div class="container">
            <div class="row">
                <h1 class="fs-5">WELCOME</h1>
                <h1><?php echo $name; ?></h1>
            </div>
            <div class="row">
                <form action="index.php" method="post">
                    <button class="btn btn-sm btn-secondary"  name="logout">Logout</button>
                </form>
            </div>
        </div>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>